/* What’s Your Music Taste? * 
* A landing page with the heading, “What’s Your Music Taste?“* 
* A button that allows the user to start the quiz which will navigate them to a multiple choice quiz.*
* Listen to the button click event to scroll to the quiz section. * 
* A quiz that prompts user to answer three questions. * 
* -Each question will have 3 answers, each answer is designated with specific points.
* Store the user selections. 
* -and get points associated with the answer *
* Upon quiz submission, display picture of album recommendation based on answers selected *
*   -Upon submission, tally up the total points from user selection, display the album recommendation 
    with picture that best match the total points range */ 


    /* I changed my MVP to get question 1 to correlate to a specific album
    my jQuery understanding is still beginner so I was not able to fully execute that goal */

       $(document).ready(function() {
        console.log("ready!");
       });


    // Question 1
    const question = [ "Morning", "Afternoon", "Late at night"];
    
       
       $("form").on("submit", function(event) {
        event.preventDefault();

        //  store value from user selected option
       const timeOfDay = $("input[name=timeOfDay]:checked").val();
       // check that console.log is printing user's value
       console.log(timeOfDay)

       // check that forEach loop is working
       question.forEach(function(selectIndex) {
          // select one index in array
          console.log(selectIndex)
          // write if statement that matches user input to one index in question array
          if (timeOfDay = selectIndex) {
        // based on user selection, pull the matching answer from music array 
              console.log($(".results").html(`<img src="Epoch.jpg" alt="Epoch by Alfa Mist">
              <p>Title: ${selectIndex}</p>`));
          }

      $("yazminLacey").css("display", "none");
      $("nickHakim").css("display", "none");
      $("alfaMist").css("display", "none");
     
        }
    }) 
